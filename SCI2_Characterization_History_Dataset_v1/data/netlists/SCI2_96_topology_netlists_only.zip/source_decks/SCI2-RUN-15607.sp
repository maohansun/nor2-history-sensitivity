* SCI2 pilot renderer E1/E3 interface V1
* run_id=SCI2-RUN-15607
* technology=PTM65
* topology=NOR2
* position=POS-B
* vehicle=NOR2_SW_TOP
.option numdgt=15
.temp 25
.param VDD=0.950000
.param L=65n
.param WN=130n
.param WP=520n
.include "/home/eda/EQCC_ROUTE_A_FINAL_26-34/01_inputs/models/base/PTM65_fresh.lib"
Vdd vdd 0 VDD
Vin in 0 PULSE(0 VDD 1n 1p 1p 7.499000n 10n)

.subckt nor2_sw_top_Xg01 y sw fix vdd vss
MXg01PTop netp sw vdd vdd pmos W='WP' L='L'
MXg01PBottom y fix netp vdd pmos W='WP' L='L'
MXg01NSw y sw vss vss nmos W='WN' L='L'
MXg01NFix y fix vss vss nmos W='WN' L='L'
.ends nor2_sw_top_Xg01

.subckt nor2_sw_top_Xg02 y sw fix vdd vss
MXg02PTop netp sw vdd vdd pmos W='WP' L='L'
MXg02PBottom y fix netp vdd pmos W='WP' L='L'
MXg02NSw y sw vss vss nmos W='WN' L='L'
MXg02NFix y fix vss vss nmos W='WN' L='L'
.ends nor2_sw_top_Xg02

.subckt nor2_sw_top_Xg03 y sw fix vdd vss
MXg03PTop netp sw vdd vdd pmos W='WP' L='L'
MXg03PBottom y fix netp vdd pmos W='WP' L='L'
MXg03NSw y sw vss vss nmos W='WN' L='L'
MXg03NFix y fix vss vss nmos W='WN' L='L'
.ends nor2_sw_top_Xg03

.subckt nor2_sw_top_Xg04 y sw fix vdd vss
MXg04PTop netp sw vdd vdd pmos W='WP' L='L'
MXg04PBottom y fix netp vdd pmos W='WP' L='L'
MXg04NSw y sw vss vss nmos W='WN' L='L'
MXg04NFix y fix vss vss nmos W='WN' L='L'
.ends nor2_sw_top_Xg04

.subckt nor2_sw_top_Xg05 y sw fix vdd vss
MXg05PTop netp sw vdd vdd pmos W='WP' L='L'
MXg05PBottom y fix netp vdd pmos W='WP' L='L'
MXg05NSw y sw vss vss nmos W='WN' L='L'
MXg05NFix y fix vss vss nmos W='WN' L='L'
.ends nor2_sw_top_Xg05

.subckt nor2_sw_top_Xg06 y sw fix vdd vss
MXg06PTop netp sw vdd vdd pmos W='WP' L='L'
MXg06PBottom y fix netp vdd pmos W='WP' L='L'
MXg06NSw y sw vss vss nmos W='WN' L='L'
MXg06NFix y fix vss vss nmos W='WN' L='L'
.ends nor2_sw_top_Xg06

.subckt nor2_sw_top_Xg07 y sw fix vdd vss
MXg07PTop netp sw vdd vdd pmos W='WP' L='L'
MXg07PBottom y fix netp vdd pmos W='WP' L='L'
MXg07NSw y sw vss vss nmos W='WN' L='L'
MXg07NFix y fix vss vss nmos W='WN' L='L'
.ends nor2_sw_top_Xg07

Xg01 n01 in 0 vdd 0 nor2_sw_top_Xg01
Xg02 n02 n01 0 vdd 0 nor2_sw_top_Xg02
Xg03 n03 n02 0 vdd 0 nor2_sw_top_Xg03
Xg04 n04 n03 0 vdd 0 nor2_sw_top_Xg04
Xg05 n05 n04 0 vdd 0 nor2_sw_top_Xg05
Xg06 n06 n05 0 vdd 0 nor2_sw_top_Xg06
Xg07 out n06 0 vdd 0 nor2_sw_top_Xg07
.tran 0.1p 81n 0 0.1p
.save v(in) v(n01) v(n02) v(n03) v(n04) v(n05) v(n06) v(out) v(xg01.netp) v(xg02.netp) v(xg03.netp) v(xg04.netp) v(xg05.netp) v(xg06.netp) v(xg07.netp)
.end
