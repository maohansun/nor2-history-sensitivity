* SCI2 pilot renderer E1/E3 interface V1
* run_id=SCI2-RUN-15640
* technology=PTM65
* topology=NAND2
* position=POS-A
* vehicle=NAND2_SW_TOP
.option numdgt=15
.temp 125
.param VDD=0.950000
.param L=65n
.param WN=130n
.param WP=520n
.include "/home/eda/EQCC_ROUTE_A_FINAL_26-34/01_inputs/models/base/PTM65_fresh.lib"
Vdd vdd 0 VDD
Vin in 0 PULSE(0 VDD 1n 1p 1p 2.499000n 10n)

.subckt nand2_sw_top_Xg01 y sw fix vdd vss
MXg01PSw y sw vdd vdd pmos W='WP' L='L'
MXg01PFix y fix vdd vdd pmos W='WP' L='L'
MXg01NTop y sw netn vss nmos W='WN' L='L'
MXg01NBottom netn fix vss vss nmos W='WN' L='L'
.ends nand2_sw_top_Xg01

.subckt nand2_sw_top_Xg02 y sw fix vdd vss
MXg02PSw y sw vdd vdd pmos W='WP' L='L'
MXg02PFix y fix vdd vdd pmos W='WP' L='L'
MXg02NTop y sw netn vss nmos W='WN' L='L'
MXg02NBottom netn fix vss vss nmos W='WN' L='L'
.ends nand2_sw_top_Xg02

.subckt nand2_sw_top_Xg03 y sw fix vdd vss
MXg03PSw y sw vdd vdd pmos W='WP' L='L'
MXg03PFix y fix vdd vdd pmos W='WP' L='L'
MXg03NTop y sw netn vss nmos W='WN' L='L'
MXg03NBottom netn fix vss vss nmos W='WN' L='L'
.ends nand2_sw_top_Xg03

.subckt nand2_sw_top_Xg04 y sw fix vdd vss
MXg04PSw y sw vdd vdd pmos W='WP' L='L'
MXg04PFix y fix vdd vdd pmos W='WP' L='L'
MXg04NTop y sw netn vss nmos W='WN' L='L'
MXg04NBottom netn fix vss vss nmos W='WN' L='L'
.ends nand2_sw_top_Xg04

.subckt nand2_sw_top_Xg05 y sw fix vdd vss
MXg05PSw y sw vdd vdd pmos W='WP' L='L'
MXg05PFix y fix vdd vdd pmos W='WP' L='L'
MXg05NTop y sw netn vss nmos W='WN' L='L'
MXg05NBottom netn fix vss vss nmos W='WN' L='L'
.ends nand2_sw_top_Xg05

.subckt nand2_sw_top_Xg06 y sw fix vdd vss
MXg06PSw y sw vdd vdd pmos W='WP' L='L'
MXg06PFix y fix vdd vdd pmos W='WP' L='L'
MXg06NTop y sw netn vss nmos W='WN' L='L'
MXg06NBottom netn fix vss vss nmos W='WN' L='L'
.ends nand2_sw_top_Xg06

.subckt nand2_sw_top_Xg07 y sw fix vdd vss
MXg07PSw y sw vdd vdd pmos W='WP' L='L'
MXg07PFix y fix vdd vdd pmos W='WP' L='L'
MXg07NTop y sw netn vss nmos W='WN' L='L'
MXg07NBottom netn fix vss vss nmos W='WN' L='L'
.ends nand2_sw_top_Xg07

Xg01 n01 in vdd vdd 0 nand2_sw_top_Xg01
Xg02 n02 n01 vdd vdd 0 nand2_sw_top_Xg02
Xg03 n03 n02 vdd vdd 0 nand2_sw_top_Xg03
Xg04 n04 n03 vdd vdd 0 nand2_sw_top_Xg04
Xg05 n05 n04 vdd vdd 0 nand2_sw_top_Xg05
Xg06 n06 n05 vdd vdd 0 nand2_sw_top_Xg06
Xg07 out n06 vdd vdd 0 nand2_sw_top_Xg07
.tran 0.1p 81n 0 0.1p
.save v(in) v(n01) v(n02) v(n03) v(n04) v(n05) v(n06) v(out) v(xg01.netn) v(xg02.netn) v(xg03.netn) v(xg04.netn) v(xg05.netn) v(xg06.netn) v(xg07.netn)
.end
